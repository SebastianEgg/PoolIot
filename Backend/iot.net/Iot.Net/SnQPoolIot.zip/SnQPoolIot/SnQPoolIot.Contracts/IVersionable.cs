﻿//@CodeCopy

namespace SnQPoolIot.Contracts
{
	public partial interface IVersionable : IIdentifiable
	{
		byte[] RowVersion { get; }
	}
}
