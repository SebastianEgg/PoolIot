﻿//@CodeCopy
//MdStart

namespace SnQPoolIot.Contracts
{
    public partial interface IShadow<TSource> : IIdentifiable
        where TSource : IIdentifiable
    {
    }
}
//MdEnd
