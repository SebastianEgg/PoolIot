﻿//@CodeCopy
//MdStart
#if ACCOUNT_ON
namespace SnQPoolIot.Contracts.Modules.Account
{
    public partial interface IJsonWebLogon
    {
        string Token { get; set; }
    }
}
#endif
//MdEnd
