﻿//@CodeCopy
//MdStart
namespace SnQPoolIot.Contracts.Modules.Common
{
    /// <summary>
    /// Source: http://www.lingoes.net/en/translator/langcode.htm
    /// </summary>
    public enum LanguageCode
    {
        De = 1,
        En = 2,
        Fr = 3,
        Tr = 4,
    }
}
//MdEnd
