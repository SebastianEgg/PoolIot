﻿//@CodeCopy

namespace SnQPoolIot.Contracts
{
	public partial interface IIdentifiable
	{
		int Id { get; }
	}
}
