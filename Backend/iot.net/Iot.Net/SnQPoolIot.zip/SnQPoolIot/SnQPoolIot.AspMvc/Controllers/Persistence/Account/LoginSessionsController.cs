//@GeneratedCode
namespace SnQPoolIot.AspMvc.Controllers.Persistence.Account
{
    using Microsoft.AspNetCore.Mvc;
    using System.Threading.Tasks;
    using TContract = Contracts.Persistence.Account.ILoginSession;
    using TModel = AspMvc.Models.Persistence.Account.LoginSession;
    public partial class LoginSessionsController : AspMvc.Controllers.GenericController<TContract, TModel>
    {
    }
}
