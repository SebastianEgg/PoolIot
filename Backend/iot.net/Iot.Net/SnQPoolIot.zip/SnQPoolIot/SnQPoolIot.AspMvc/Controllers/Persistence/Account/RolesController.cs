//@GeneratedCode
namespace SnQPoolIot.AspMvc.Controllers.Persistence.Account
{
    using Microsoft.AspNetCore.Mvc;
    using System.Threading.Tasks;
    using TContract = Contracts.Persistence.Account.IRole;
    using TModel = AspMvc.Models.Persistence.Account.Role;
    public partial class RolesController : AspMvc.Controllers.GenericController<TContract, TModel>
    {
    }
}
