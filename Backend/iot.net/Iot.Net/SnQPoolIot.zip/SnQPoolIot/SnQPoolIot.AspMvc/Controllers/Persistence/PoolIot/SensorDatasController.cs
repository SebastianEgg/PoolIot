//@GeneratedCode
namespace SnQPoolIot.AspMvc.Controllers.Persistence.PoolIot
{
    using Microsoft.AspNetCore.Mvc;
    using System.Threading.Tasks;
    using TContract = Contracts.Persistence.PoolIot.ISensorData;
    using TModel = AspMvc.Models.Persistence.PoolIot.SensorData;
    public partial class SensorDatasController : AspMvc.Controllers.GenericController<TContract, TModel>
    {
    }
}
