//@GeneratedCode
namespace SnQPoolIot.AspMvc.Controllers.Persistence.Account
{
    using Microsoft.AspNetCore.Mvc;
    using System.Threading.Tasks;
    using TContract = Contracts.Persistence.Account.IActionLog;
    using TModel = AspMvc.Models.Persistence.Account.ActionLog;
    public partial class ActionLogsController : AspMvc.Controllers.GenericController<TContract, TModel>
    {
    }
}
