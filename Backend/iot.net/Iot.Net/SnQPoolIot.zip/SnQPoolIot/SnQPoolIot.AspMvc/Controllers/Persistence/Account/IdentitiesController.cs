//@GeneratedCode
namespace SnQPoolIot.AspMvc.Controllers.Persistence.Account
{
    using Microsoft.AspNetCore.Mvc;
    using System.Threading.Tasks;
    using TContract = Contracts.Persistence.Account.IIdentity;
    using TModel = AspMvc.Models.Persistence.Account.Identity;
    public partial class IdentitiesController : AspMvc.Controllers.GenericController<TContract, TModel>
    {
    }
}
