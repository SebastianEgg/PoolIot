//@GeneratedCode
namespace SnQPoolIot.AspMvc.Controllers.Persistence.PoolIot
{
    using Microsoft.AspNetCore.Mvc;
    using System.Threading.Tasks;
    using TContract = Contracts.Persistence.PoolIot.ISensor;
    using TModel = AspMvc.Models.Persistence.PoolIot.Sensor;
    public partial class SensorsController : AspMvc.Controllers.GenericController<TContract, TModel>
    {
    }
}
