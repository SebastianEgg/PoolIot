//@GeneratedCode
namespace SnQPoolIot.AspMvc.Controllers.Business.Account
{
    using Microsoft.AspNetCore.Mvc;
    using System.Threading.Tasks;
    using TContract = Contracts.Business.Account.IAppAccess;
    using TModel = AspMvc.Models.Business.Account.AppAccess;
    partial class AppAccessesController : AspMvc.Controllers.GenericController<TContract, TModel>
    {
    }
}
