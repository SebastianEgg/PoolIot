//@GeneratedCode
namespace SnQPoolIot.AspMvc.Controllers.Business.Account
{
    using Microsoft.AspNetCore.Mvc;
    using System.Threading.Tasks;
    using TContract = Contracts.Business.Account.IIdentityUser;
    using TModel = AspMvc.Models.Business.Account.IdentityUser;
    partial class IdentityUsersController : AspMvc.Controllers.GenericController<TContract, TModel>
    {
    }
}
