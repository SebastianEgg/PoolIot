﻿//@CodeCopy
//MdStart
namespace SnQPoolIot.AspMvc.Models
{
    public partial class ModuleModel : ModelObject
    {
    }
}
//MdEnd
