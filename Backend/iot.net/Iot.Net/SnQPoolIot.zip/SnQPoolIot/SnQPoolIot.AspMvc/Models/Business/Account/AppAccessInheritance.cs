//@GeneratedCode
namespace SnQPoolIot.AspMvc.Models.Business.Account
{
    partial class AppAccess : OneToManyModel<SnQPoolIot.Contracts.Persistence.Account.IIdentity, SnQPoolIot.AspMvc.Models.Persistence.Account.Identity, SnQPoolIot.Contracts.Persistence.Account.IRole, SnQPoolIot.AspMvc.Models.Persistence.Account.Role>
    {
    }
}
