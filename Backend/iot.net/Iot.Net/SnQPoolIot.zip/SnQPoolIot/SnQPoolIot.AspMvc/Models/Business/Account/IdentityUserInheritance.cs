//@GeneratedCode
namespace SnQPoolIot.AspMvc.Models.Business.Account
{
    partial class IdentityUser : OneToAnotherModel<SnQPoolIot.Contracts.Persistence.Account.IIdentity, SnQPoolIot.AspMvc.Models.Persistence.Account.Identity, SnQPoolIot.Contracts.Persistence.Account.IUser, SnQPoolIot.AspMvc.Models.Persistence.Account.User>
    {
    }
}
