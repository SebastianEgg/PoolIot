//@GeneratedCode
namespace SnQPoolIot.AspMvc.Models.ThirdParty
{
    partial class HtmlItem : VersionModel
    {
    }
}
