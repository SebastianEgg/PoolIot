//@GeneratedCode
namespace SnQPoolIot.AspMvc.Models.Persistence.Account
{
    partial class Access : IdentityModel
    {
    }
}
