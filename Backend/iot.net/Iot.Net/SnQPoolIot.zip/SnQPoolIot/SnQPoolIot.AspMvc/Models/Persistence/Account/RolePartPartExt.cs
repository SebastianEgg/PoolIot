﻿//@CodeCopy
//MdStart
#if ACCOUNT_ON

namespace SnQPoolIot.AspMvc.Models.Persistence.Account
{
    public partial class Role
    {
        public bool Assigned { get; set; }
    }
}
#endif
//MdEnd
