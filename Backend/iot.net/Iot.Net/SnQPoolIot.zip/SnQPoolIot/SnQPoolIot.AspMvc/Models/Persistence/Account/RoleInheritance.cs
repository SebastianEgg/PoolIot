//@GeneratedCode
namespace SnQPoolIot.AspMvc.Models.Persistence.Account
{
    partial class Role : VersionModel
    {
    }
}
