//@GeneratedCode
namespace SnQPoolIot.AspMvc.Models.Persistence.Account
{
    partial class IdentityXRole : VersionModel
    {
    }
}
