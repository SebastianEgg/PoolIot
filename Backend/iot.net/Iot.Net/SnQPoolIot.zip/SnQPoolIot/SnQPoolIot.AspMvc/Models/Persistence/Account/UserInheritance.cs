//@GeneratedCode
namespace SnQPoolIot.AspMvc.Models.Persistence.Account
{
    partial class User : VersionModel
    {
    }
}
