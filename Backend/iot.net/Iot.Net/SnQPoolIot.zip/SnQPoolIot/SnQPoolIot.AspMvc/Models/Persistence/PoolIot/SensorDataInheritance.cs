//@GeneratedCode
namespace SnQPoolIot.AspMvc.Models.Persistence.PoolIot
{
    partial class SensorData : VersionModel
    {
    }
}
