﻿//@CodeCopy
//MdStart
namespace SnQPoolIot.AspMvc.Models
{
    public abstract partial class ShadowModel : IdentityModel
    {
    }
}
//MdEnd
