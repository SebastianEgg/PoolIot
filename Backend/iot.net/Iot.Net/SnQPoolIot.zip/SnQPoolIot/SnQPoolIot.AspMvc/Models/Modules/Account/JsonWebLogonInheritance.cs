//@GeneratedCode
namespace SnQPoolIot.AspMvc.Models.Modules.Account
{
    partial class JsonWebLogon : ModuleModel
    {
    }
}
