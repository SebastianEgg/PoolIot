﻿//@CodeCopy
//MdStart
namespace SnQPoolIot.AspMvc.Models.Modules.Common
{
    public enum ActionMode : int
    {
        Index,
        Display,
        Create,
        Edit,
        Delete,
        Details,
    }
}
//MdEnd
