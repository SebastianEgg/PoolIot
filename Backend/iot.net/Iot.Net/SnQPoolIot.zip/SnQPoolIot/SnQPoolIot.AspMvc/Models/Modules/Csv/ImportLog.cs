﻿//@CodeCopy
//MdStart

namespace SnQPoolIot.AspMvc.Models.Modules.Csv
{
    public class ImportLog
    {
        public bool IsError { get; set; }
        public string Prefix { get; set; }
        public string Text { get; set; }
    }
}
//MdEnd
