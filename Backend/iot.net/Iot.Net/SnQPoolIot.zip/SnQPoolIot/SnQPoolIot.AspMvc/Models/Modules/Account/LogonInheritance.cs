//@GeneratedCode
namespace SnQPoolIot.AspMvc.Models.Modules.Account
{
    partial class Logon : ModuleModel
    {
    }
}
