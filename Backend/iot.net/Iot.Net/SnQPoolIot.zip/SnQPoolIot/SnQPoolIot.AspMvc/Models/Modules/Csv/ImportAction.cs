﻿//@CodeCopy
//MdStart

namespace SnQPoolIot.AspMvc.Models.Modules.Csv
{
    public enum ImportAction
    {
        None = 0,
        Insert = 1,
        Update = 2,
        Delete = 4,
    }
}
//MdEnd
