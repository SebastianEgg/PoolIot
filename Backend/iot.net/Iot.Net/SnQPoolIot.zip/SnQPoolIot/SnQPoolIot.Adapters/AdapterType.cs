﻿//@CodeCopy
//MdStart

namespace SnQPoolIot.Adapters
{
    public enum AdapterType
    {
        Controller = 1,
        Service = 2,
    }
}
//MdEnd
