//@GeneratedCode
namespace SnQPoolIot.Transfer.Models.Modules.Account
{
    partial class Logon : ModuleModel
    {
    }
}
