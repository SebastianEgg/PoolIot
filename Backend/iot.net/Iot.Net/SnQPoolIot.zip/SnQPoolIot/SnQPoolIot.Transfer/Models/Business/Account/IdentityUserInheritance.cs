//@GeneratedCode
namespace SnQPoolIot.Transfer.Models.Business.Account
{
    partial class IdentityUser : OneToAnotherModel<SnQPoolIot.Contracts.Persistence.Account.IIdentity, SnQPoolIot.Transfer.Models.Persistence.Account.Identity, SnQPoolIot.Contracts.Persistence.Account.IUser, SnQPoolIot.Transfer.Models.Persistence.Account.User>
    {
    }
}
