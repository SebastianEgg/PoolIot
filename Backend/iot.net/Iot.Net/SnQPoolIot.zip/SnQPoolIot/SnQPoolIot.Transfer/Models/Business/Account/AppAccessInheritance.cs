//@GeneratedCode
namespace SnQPoolIot.Transfer.Models.Business.Account
{
    partial class AppAccess : OneToManyModel<SnQPoolIot.Contracts.Persistence.Account.IIdentity, SnQPoolIot.Transfer.Models.Persistence.Account.Identity, SnQPoolIot.Contracts.Persistence.Account.IRole, SnQPoolIot.Transfer.Models.Persistence.Account.Role>
    {
    }
}
