//@GeneratedCode
namespace SnQPoolIot.Transfer.Models.Persistence.Account
{
    partial class IdentityXRole : VersionModel
    {
    }
}
