//@GeneratedCode
namespace SnQPoolIot.Transfer.Models.Persistence.Account
{
    partial class ActionLog : VersionModel
    {
    }
}
