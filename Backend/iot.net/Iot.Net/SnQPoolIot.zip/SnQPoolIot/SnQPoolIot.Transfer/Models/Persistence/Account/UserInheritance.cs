//@GeneratedCode
namespace SnQPoolIot.Transfer.Models.Persistence.Account
{
    partial class User : VersionModel
    {
    }
}
