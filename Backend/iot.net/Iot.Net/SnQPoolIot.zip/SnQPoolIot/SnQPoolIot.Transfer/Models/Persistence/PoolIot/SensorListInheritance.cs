//@GeneratedCode
namespace SnQPoolIot.Transfer.Models.Persistence.PoolIot
{
    partial class Sensor : VersionModel
    {
    }
}
