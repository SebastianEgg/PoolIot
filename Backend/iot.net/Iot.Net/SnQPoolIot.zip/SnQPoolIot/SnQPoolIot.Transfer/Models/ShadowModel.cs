﻿//@CodeCopy
//MdStart

namespace SnQPoolIot.Transfer.Models
{
    public abstract partial class ShadowModel : IdentityModel
    {
    }
}
//MdEnd
