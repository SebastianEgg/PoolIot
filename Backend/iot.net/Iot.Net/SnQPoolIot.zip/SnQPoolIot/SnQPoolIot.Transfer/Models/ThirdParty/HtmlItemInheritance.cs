//@GeneratedCode
namespace SnQPoolIot.Transfer.Models.ThirdParty
{
    partial class HtmlItem : VersionModel
    {
    }
}
