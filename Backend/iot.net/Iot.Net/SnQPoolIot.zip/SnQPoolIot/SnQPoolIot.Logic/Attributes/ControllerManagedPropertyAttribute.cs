﻿//@CodeCopy
//MdStart
using System;

namespace SnQPoolIot.Logic.Attributes
{
    [AttributeUsage(AttributeTargets.Property)]
    class ControllerManagedPropertyAttribute : Attribute
    {
    }
}
//MdEnd
