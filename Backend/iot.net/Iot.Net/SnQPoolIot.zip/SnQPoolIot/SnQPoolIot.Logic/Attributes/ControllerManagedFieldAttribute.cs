﻿//@CodeCopy
//MdStart
using System;

namespace SnQPoolIot.Logic.Attributes
{
    [AttributeUsage(AttributeTargets.Field)]
    class ControllerManagedFieldAttribute : Attribute
    {
    }
}
//MdEnd
