//@GeneratedCode
namespace SnQPoolIot.Logic.Entities.Business.Account
{
    partial class AppAccess : OneToManyEntity<SnQPoolIot.Contracts.Persistence.Account.IIdentity, SnQPoolIot.Logic.Entities.Persistence.Account.Identity, SnQPoolIot.Contracts.Persistence.Account.IRole, SnQPoolIot.Logic.Entities.Persistence.Account.Role>
    {
    }
}
