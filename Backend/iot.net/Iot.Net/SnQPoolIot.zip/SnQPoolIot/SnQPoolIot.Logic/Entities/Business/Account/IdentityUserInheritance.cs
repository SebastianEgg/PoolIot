//@GeneratedCode
namespace SnQPoolIot.Logic.Entities.Business.Account
{
    partial class IdentityUser : OneToAnotherEntity<SnQPoolIot.Contracts.Persistence.Account.IIdentity, SnQPoolIot.Logic.Entities.Persistence.Account.Identity, SnQPoolIot.Contracts.Persistence.Account.IUser, SnQPoolIot.Logic.Entities.Persistence.Account.User>
    {
    }
}
