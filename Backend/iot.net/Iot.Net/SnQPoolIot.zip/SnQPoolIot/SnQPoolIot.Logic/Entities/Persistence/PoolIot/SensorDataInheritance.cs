//@GeneratedCode
namespace SnQPoolIot.Logic.Entities.Persistence.PoolIot
{
    partial class SensorData : VersionEntity
    {
    }
}
