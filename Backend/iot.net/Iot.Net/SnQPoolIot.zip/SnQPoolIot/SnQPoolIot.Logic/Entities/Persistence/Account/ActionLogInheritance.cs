//@GeneratedCode
namespace SnQPoolIot.Logic.Entities.Persistence.Account
{
    partial class ActionLog : VersionEntity
    {
    }
}
