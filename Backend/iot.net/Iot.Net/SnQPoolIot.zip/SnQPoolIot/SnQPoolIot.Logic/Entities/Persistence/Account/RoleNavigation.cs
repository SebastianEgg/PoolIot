//@GeneratedCode
namespace SnQPoolIot.Logic.Entities.Persistence.Account
{
    partial class Role
    {
        public System.Collections.Generic.ICollection<SnQPoolIot.Logic.Entities.Persistence.Account.IdentityXRole> IdentityXRoles
        {
            get;
            set;
        }
    }
}
