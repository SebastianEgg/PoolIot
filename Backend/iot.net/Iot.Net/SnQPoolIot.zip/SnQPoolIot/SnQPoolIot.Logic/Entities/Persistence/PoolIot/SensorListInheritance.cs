//@GeneratedCode
namespace SnQPoolIot.Logic.Entities.Persistence.PoolIot
{
    partial class Sensor : VersionEntity
    {
    }
}
