//@GeneratedCode
namespace SnQPoolIot.Logic.Entities.Persistence.Account
{
    partial class Identity
    {
        public System.Collections.Generic.ICollection<SnQPoolIot.Logic.Entities.Persistence.Account.Access> Accesss
        {
            get;
            set;
        }
        public System.Collections.Generic.ICollection<SnQPoolIot.Logic.Entities.Persistence.Account.ActionLog> ActionLogs
        {
            get;
            set;
        }
        public System.Collections.Generic.ICollection<SnQPoolIot.Logic.Entities.Persistence.Account.IdentityXRole> IdentityXRoles
        {
            get;
            set;
        }
        public System.Collections.Generic.ICollection<SnQPoolIot.Logic.Entities.Persistence.Account.LoginSession> LoginSessions
        {
            get;
            set;
        }
        public System.Collections.Generic.ICollection<SnQPoolIot.Logic.Entities.Persistence.Account.User> Users
        {
            get;
            set;
        }
    }
}
