//@GeneratedCode
namespace SnQPoolIot.Logic.Entities.Persistence.PoolIot
{
    partial class Sensor
    {
        public System.Collections.Generic.ICollection<SnQPoolIot.Logic.Entities.Persistence.PoolIot.SensorData> SensorDatas
        {
            get;
            set;
        }
    }
}
