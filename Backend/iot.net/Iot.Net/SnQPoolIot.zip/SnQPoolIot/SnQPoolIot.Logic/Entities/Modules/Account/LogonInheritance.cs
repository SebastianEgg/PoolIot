//@GeneratedCode
namespace SnQPoolIot.Logic.Entities.Modules.Account
{
    partial class Logon : ModuleObject
    {
    }
}
