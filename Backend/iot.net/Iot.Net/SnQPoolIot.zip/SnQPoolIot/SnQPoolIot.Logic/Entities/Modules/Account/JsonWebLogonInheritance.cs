//@GeneratedCode
namespace SnQPoolIot.Logic.Entities.Modules.Account
{
    partial class JsonWebLogon : ModuleObject
    {
    }
}
