﻿//@CodeCopy
//MdStart

namespace SnQPoolIot.Logic.Entities
{
    internal abstract partial class ShadowEntity : IdentityEntity
    {
    }
}
//MdEnd
