﻿//@CodeCopy
//MdStart
using System;

namespace CommonBase.Attributes
{
    [AttributeUsage(AttributeTargets.Field)]
    public partial class DisposeFieldAttribute : Attribute
    {
    }
}
//MdEnd
