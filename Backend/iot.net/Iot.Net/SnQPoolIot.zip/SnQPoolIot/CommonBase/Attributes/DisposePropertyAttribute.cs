﻿//@CodeCopy
//MdStart
using System;

namespace CommonBase.Attributes
{
    [AttributeUsage(AttributeTargets.Property)]
    public partial class DisposePropertyAttribute : Attribute
    {
    }
}
//MdEnd
