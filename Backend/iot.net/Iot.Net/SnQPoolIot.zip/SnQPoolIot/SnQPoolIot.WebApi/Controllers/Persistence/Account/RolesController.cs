//@GeneratedCode
namespace SnQPoolIot.WebApi.Controllers.Persistence.Account
{
    using Microsoft.AspNetCore.Mvc;
    using TContract = Contracts.Persistence.Account.IRole;
    using TModel = Transfer.Models.Persistence.Account.Role;
    [ApiController]
    [Route("Controller")]
    public partial class RolesController : WebApi.Controllers.GenericController<TContract, TModel>
    {
    }
}
