//@GeneratedCode
namespace SnQPoolIot.WebApi.Controllers.Persistence.Account
{
    using Microsoft.AspNetCore.Mvc;
    using TContract = Contracts.Persistence.Account.IIdentityXRole;
    using TModel = Transfer.Models.Persistence.Account.IdentityXRole;
    [ApiController]
    [Route("Controller")]
    public partial class IdentityXRolesController : WebApi.Controllers.GenericController<TContract, TModel>
    {
    }
}
